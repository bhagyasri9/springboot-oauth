---
--- create database
---
CREATE DATABASE spring_boot_2_and_oauth2_db;

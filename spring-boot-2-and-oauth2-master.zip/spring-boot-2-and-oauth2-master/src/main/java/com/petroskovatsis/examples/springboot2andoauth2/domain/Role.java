package com.petroskovatsis.examples.springboot2andoauth2.domain;

public enum Role {

    ROLE_USER
}
